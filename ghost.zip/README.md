# ⚡ SLM Benchmark

<div align="center">

**Comprehensive, Unbiased Benchmarking Platform for Small Language Models**

[![License](https://img.shields.io/badge/License-Apache%202.0-blue.svg)](LICENSE)
[![Python 3.11+](https://img.shields.io/badge/python-3.11+-blue.svg)](https://www.python.org/downloads/)
[![GitHub Stars](https://img.shields.io/github/stars/2796gaurav/slm-benchmark?style=social)](https://github.com/2796gaurav/slm-benchmark)
[![Website](https://img.shields.io/badge/website-live-green)](https://2796gaurav.github.io/slm-benchmark/)

[🌐 Live Leaderboard](https://2796gaurav.github.io/slm-benchmark/) • [📊 Methodology](https://2796gaurav.github.io/slm-benchmark/methodology.html) • [📝 Submit Model](https://2796gaurav.github.io/slm-benchmark/submit.html) • [💬 Discussions](https://github.com/2796gaurav/slm-benchmark/discussions)

</div>

---

## 🎯 What is SLM Benchmark?

**SLM Benchmark** is a free, open-source evaluation platform specifically designed for **Small Language Models** (1M–3B parameters). Unlike general-purpose LLM benchmarks, we focus on models that can run efficiently on CPUs, edge devices, and resource-constrained environments.

### Why SLM Benchmark?

- **🎯 Small Model Focus**: Optimized for 1M–3B parameter models
- **💻 CPU-Friendly**: All benchmarks run on CPU (no GPU required)
- **🔬 Comprehensive**: 5 core evaluation pillars + advanced metrics
- **🌍 Transparent**: Open methodology, reproducible results
- **⚡ Automated**: Submit via PR, benchmarks run automatically
- **🆓 Free**: Zero cost, community-driven infrastructure

---

## 🚀 Quick Start

### Installation

```bash
# Clone the repository
git clone https://github.com/2796gaurav/slm-benchmark.git
cd slm-benchmark

# Create virtual environment
python -m venv .venv
source .venv/bin/activate  # On Windows: .venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt
```

### Run Your First Benchmark

```bash
# Use the template to create a submission
cp models/submissions/template.yaml models/submissions/my-model.yaml

# Edit my-model.yaml to point to your HuggingFace model
# Example: hf_repo: "HuggingFaceTB/SmolLM2-135M"

# Run a quick test (5 samples per task)
python benchmarks/evaluation/run_benchmark.py \
  --submission-file models/submissions/my-model.yaml \
  --output-dir results/test/ \
  --limit 5
```

---

## 📊 Evaluation Pillars

SLM Benchmark evaluates models across **5 core dimensions**:

| Pillar | Weight | Benchmarks | Description |
|--------|--------|------------|-------------|
| 🧠 **Reasoning** | 35% | MMLU, ARC-Challenge, HellaSwag, TruthfulQA | Logical deduction, common sense, factual accuracy |
| 💻 **Coding** | 20% | HumanEval, MBPP | Python code generation, algorithmic problem-solving |
| 🔢 **Math** | 15% | GSM8K, MATH | Multi-step quantitative reasoning |
| 📚 **Language** | 20% | BoolQ, PIQA, WinoGrande | Reading comprehension, linguistic patterns |
| 🛡️ **Safety** | 20% | Toxicity, Bias, Truthfulness | Model alignment, fairness, reliability |

### Aggregate Score Formula

```
Score = 0.35·Reasoning + 0.20·Coding + 0.15·Math + 0.20·Language + 0.20·Safety
```

> **Note**: Hardware-dependent metrics (latency, memory, energy) are reported separately but **not included in rankings** to ensure fairness across different machines.

---

## 📝 Submit Your Model

### Prerequisites

- ✅ Model is public on [HuggingFace Hub](https://huggingface.co/models)
- ✅ ≤ 3B parameters (ideally ≤ 1B for CI compatibility)
- ✅ License permits benchmarking and public result publication
- ✅ Works with `transformers` library (`AutoModelForCausalLM`)

### Submission Process

**1. Create Submission YAML**

```yaml
# models/submissions/my-model.yaml
model:
  hf_repo: "username/model-name"  # Required - your HuggingFace repo
  
# Optional: We auto-detect everything else!
# name: "Custom Display Name"
# categories: ["reasoning", "coding"]  # Restrict to specific benchmarks
```

**2. Submit via Pull Request**

```bash
# Fork the repository
git clone https://github.com/YOUR-USERNAME/slm-benchmark.git
cd slm-benchmark

# Create branch
git checkout -b feat/add-mymodel

# Add your submission
cp models/submissions/template.yaml models/submissions/my-model.yaml
# Edit my-model.yaml with your model details

# Commit and push
git add models/submissions/my-model.yaml
git commit -m "Add [Model Name] for evaluation"
git push origin feat/add-mymodel

# Open PR on GitHub
```

**3. Automated Validation**

Our CI system will:
- ✅ Validate YAML format
- ✅ Check model exists on HuggingFace
- ✅ Verify parameter count ≤ 3B
- ✅ Detect quantizations and architecture
- ✅ Post validation report as PR comment

**4. Benchmark Execution**

After maintainer approval:
- Maintainer comments `/full-benchmark` to start evaluation
- Benchmarks run automatically (2-6 hours)
- Results posted as PR comment
- Maintainer comments `/publish-results` to add to leaderboard

**5. Leaderboard Update**

Your model appears on the [live leaderboard](https://2796gaurav.github.io/slm-benchmark/) with:
- Overall rank and aggregate score
- Per-pillar scores (reasoning, coding, math, language, safety)
- Edge metrics (latency, memory, CO₂)
- Link to HuggingFace model card

### Example Submission

See [`models/submissions/template.yaml`](models/submissions/template.yaml) for a complete example.

---

## 🏗️ Architecture

```mermaid
graph TB
    A[User Submits PR] --> B[GitHub Actions: Validate]
    B --> C{Valid?}
    C -->|No| D[Comment Errors]
    C -->|Yes| E[Maintainer Approval]
    E --> F[Run Benchmarks]
    F --> G[Generate Report]
    G --> H[Update Registry]
    H --> I[Deploy Website]
    I --> J[Live Leaderboard]
```

### Key Components

- **`.github/workflows/`**: GitHub Actions for CI/CD
  - `01-validate-pr.yml`: Validates submissions
  - `02-submission-workflow.yml`: Runs benchmarks
  - `deploy-website.yml`: Deploys to GitHub Pages
  
- **`benchmarks/evaluation/`**: Benchmark runners
  - `run_benchmark.py`: Main orchestrator
  - `*_eval.py`: Individual evaluation modules
  
- **`benchmarks/validation/`**: Validation logic
  - `auto_detector.py`: Auto-detects model properties from HuggingFace
  
- **`scripts/`**: Utility scripts
  - `generate_report.py`: Aggregates benchmark results
  - `update_registry.py`: Updates model registry
  - `update_website.py`: Generates leaderboard JSON
  
- **`website/`**: Static GitHub Pages site
  - Interactive leaderboard with sorting/filtering
  - Model detail pages with charts
  - Submission guide and methodology

---

## 🛠️ Development

### Setup Development Environment

```bash
# Install dev dependencies
pip install -r requirements.txt
pip install pytest flake8 black

# Run tests
pytest tests/ -v

# Lint code
flake8 benchmarks/ scripts/ --max-line-length=120
black --check benchmarks/ scripts/
```

### Project Structure

```
slm-benchmark/
├── .github/
│   ├── scripts/          # Validation and helper scripts
│   └── workflows/        # GitHub Actions workflows
├── benchmarks/
│   ├── configs/          # Benchmark configurations
│   ├── evaluation/       # Evaluation modules
│   └── validation/       # Submission validation
├── models/
│   ├── registry.json     # Leaderboard data
│   └── submissions/      # Model submission YAMLs
├── scripts/              # Utility scripts
├── website/              # GitHub Pages site
│   ├── assets/
│   │   ├── css/
│   │   ├── js/
│   │   └── data/         # leaderboard.json
│   └── *.html
├── tests/                # Unit and integration tests
└── requirements.txt
```

### Adding a New Benchmark

1. Create evaluation module in `benchmarks/evaluation/`
2. Implement evaluation logic using `lm-eval` or custom code
3. Update `run_benchmark.py` to call your module
4. Add to aggregate score calculation (if applicable)
5. Update methodology documentation

See [`DEVELOPER_GUIDE.md`](DEVELOPER_GUIDE.md) for detailed instructions.

---

## 📖 Documentation

- **[Methodology](https://2796gaurav.github.io/slm-benchmark/methodology.html)**: Detailed scoring methodology
- **[Submit Model](https://2796gaurav.github.io/slm-benchmark/submit.html)**: Step-by-step submission guide
- **[Developer Guide](DEVELOPER_GUIDE.md)**: Architecture and development workflow
- **[Contributing](CONTRIBUTING.md)**: How to contribute to the project
- **[Troubleshooting](TROUBLESHOOTING.md)**: Common issues and solutions
- **[Support](SUPPORT.md)**: Getting help

---

## 🤝 Contributing

We welcome contributions! Here's how you can help:

- **Submit Models**: Add new SLMs to the benchmark
- **Improve Benchmarks**: Suggest or implement new evaluation tasks
- **Enhance Website**: Improve UI/UX, add features
- **Documentation**: Fix typos, add examples, write guides
- **Bug Reports**: Report issues or suggest improvements

See [`CONTRIBUTING.md`](CONTRIBUTING.md) for guidelines.

---

## 🌟 Featured Models

| Rank | Model | Params | Aggregate | Reasoning | Coding | Math | Language | Safety |
|------|-------|--------|-----------|-----------|--------|------|----------|--------|
| 🥇 | [SmolLM2-1.7B](https://huggingface.co/HuggingFaceTB/SmolLM2-1.7B) | 1.7B | 45.2 | 48.3 | 42.1 | 38.5 | 46.8 | 52.3 |
| 🥈 | [Phi-2](https://huggingface.co/microsoft/phi-2) | 2.7B | 43.8 | 46.5 | 45.2 | 40.1 | 44.3 | 48.9 |
| 🥉 | [Qwen2-1.5B](https://huggingface.co/Qwen/Qwen2-1.5B) | 1.5B | 42.1 | 44.2 | 41.8 | 39.5 | 43.7 | 47.3 |

> **Note**: Scores are illustrative. See the [live leaderboard](https://2796gaurav.github.io/slm-benchmark/) for current rankings.

---

## 📊 Reproducibility

All benchmarks are run with:
- **Deterministic mode**: Fixed random seeds (seed=42)
- **Explicit configs**: Batch size, few-shot count documented
- **System info**: Python version, PyTorch version, hardware logged
- **Open source**: All code and data publicly available

Results may vary slightly across different hardware due to floating-point precision, but **relative rankings remain stable**.

---

## 🔬 Methodology Highlights

### Hardware-Agnostic Scoring

- **Included in ranking**: Reasoning, Coding, Math, Language, Safety
- **Excluded from ranking**: Latency, Memory, Energy, CO₂
- **Rationale**: Ensures fair comparison across different machines

### CPU-First Design

- All benchmarks run on CPU (no GPU required)
- Optimized for commodity hardware
- Supports edge deployment scenarios

### Comprehensive Safety

- Toxicity detection
- Bias and fairness probes
- Truthfulness evaluation
- Alignment checks

See [Methodology](https://2796gaurav.github.io/slm-benchmark/methodology.html) for full details.

---

## 📜 License

This project is licensed under the **Apache License 2.0**. See [`LICENSE`](LICENSE) for details.

### Third-Party Licenses

- Benchmark tasks use datasets with various licenses (see individual task documentation)
- HuggingFace models have their own licenses (check model cards)

---

## 🙏 Acknowledgments

- **[EleutherAI LM Evaluation Harness](https://github.com/EleutherAI/lm-evaluation-harness)**: Core evaluation framework
- **[HuggingFace](https://huggingface.co/)**: Model hosting and transformers library
- **[CodeCarbon](https://codecarbon.io/)**: Energy consumption tracking
- **Community Contributors**: Everyone who submits models and improves the platform

---

## 📞 Support

- **🐛 Bug Reports**: [GitHub Issues](https://github.com/2796gaurav/slm-benchmark/issues)
- **💬 Questions**: [GitHub Discussions](https://github.com/2796gaurav/slm-benchmark/discussions)
- **📧 Maintainer**: [@2796gaurav](https://github.com/2796gaurav)
- **📖 Documentation**: [Website](https://2796gaurav.github.io/slm-benchmark/)

---

## 🗺️ Roadmap

- [ ] Add multilingual benchmarks
- [ ] Support for instruction-tuned models
- [ ] Long-context evaluation (32k+ tokens)
- [ ] Function calling benchmarks
- [ ] Mobile deployment metrics
- [ ] Community-contributed benchmarks

See [GitHub Issues](https://github.com/2796gaurav/slm-benchmark/issues) for planned features.

---

<div align="center">

**Made with ⚡ by the SLM Benchmark Community**

[⭐ Star on GitHub](https://github.com/2796gaurav/slm-benchmark) • [🌐 Visit Website](https://2796gaurav.github.io/slm-benchmark/) • [📝 Submit Model](https://2796gaurav.github.io/slm-benchmark/submit.html)

</div>
